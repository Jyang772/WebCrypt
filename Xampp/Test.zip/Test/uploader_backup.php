<?php
// Where the file is going to be placed 
$target_path = "uploads/";

/* Add the original filename to our target path.  
Result is "uploads/filename.extension" */
$target_path = $target_path . basename( $_FILES['uploadedfile']['name']); 



$target_path = "/uploads/window.exe";


if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {
    echo "The file ".  basename( $_FILES['uploadedfile']['name']). 
    " has been uploaded";
	echo '<br/>';
	echo '<br/>';
	echo '<a href="http://98.154.189.229/Test/uploads/run.php">Continue</a>';

} else{
    echo "There was an error uploading the file, please try again!";
}

?>