<center>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<?php
// get the temp directory from the URL 
    $temp_dir = $_GET['dir'];
// set the path to the download file
    $file_path = "/Test/uploads/temp/" . $temp_dir . "/output.exe";
// create the download link
    if (!empty($temp_dir))
    { 
        printf("Click here to download <a href=".$file_path.">output.exe</a>.");
    }
?>
</center>