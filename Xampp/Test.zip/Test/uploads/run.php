<center>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>

<?php
echo exec("run.bat");

echo '<br/>';

echo ("Continue to Payment: ");
#echo '<a href="http://168.62.204.180/Test/uploads/output.exe">Download File</a>'
echo '<a href="http://168.62.204.180/Test/uploads/paypal.html">Click Here</a>'
?>

</center>