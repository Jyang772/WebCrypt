<center>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<?php


// Where the file is going to be placed 
$target_path = "uploads/";

/* Add the original filename to our target path.  
Result is "uploads/filename.extension" */
$target_path = $target_path . basename( $_FILES['uploadedfile']['name']); 



$filename=$_FILES['uploadedfile']['name'];
 $filetype=$_FILES['uploadedfile']['type'];
 $filename = strtolower($filename);
 $filetype = strtolower($filetype);

 //check if contain php and kill it 
 $pos = strpos($filename,'php');
 if(!($pos === false)) {
  die('error');
 }




 //get the file ext

 $file_ext = strrchr($filename, '.');


 //check if its allowed or not
 $whitelist = array(".exe"); 
 if (!(in_array($file_ext, $whitelist))) {
    die('Only executable files can be uploaded!');
 }






$target_path = "uploads/window.exe";

echo "Status: ";
echo $_FILES['uploadedfile']['error'];
echo '<br/>';

if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {

	echo "The file ".  basename( $_FILES['uploadedfile']['name']). 
    " has been uploaded";
	echo '<br/>';
	echo '<br/>';
	echo '<a href="http://168.62.204.180/Test/uploads/run.php">Continue</a>';
        

} else{
    echo "There was an error uploading the file, please try again!";
}

?>
</center>